library(shiny)

shinyUI(pageWithSidebar(
  headerPanel("Factor Analysis Web app"),
  sidebarPanel(
  HTML("<hr>"),
  HTML("<center><h2>Upload Area</h2></center><br>"),
    fileInput('file1', 'Choose CSV File',
              accept=c('text/csv', 'text/comma-separated-values,text/plain', '.csv')),
    tags$hr(),
    checkboxInput('header', 'Header', TRUE),
    radioButtons('sep', 'Separator',
                 c(Comma=',',
                   Semicolon=';',
                   Tab='\t'),
                 'Comma'),
    radioButtons('quote', 'Quote',
                 c(None='',
                   'Double Quote'='"',
                   'Single Quote'="'"),
                 'Double Quote'),
				 HTML("<hr>"),
				 HTML("<center><h2>Download your dynamic report</h2></center><br>"),
  downloadButton('report'),
  HTML("<hr>")
  ),
  
  mainPanel(
  tabsetPanel(
		tabPanel("Contents",tableOutput('contents')),
      tabPanel("Scree Plot", plotOutput("plot")), 
      tabPanel("Summary", tableOutput('summary')), 
	  tabPanel("Eigen values Table", tableOutput('eigenvalues')),
	  tabPanel("Correlation of old variables with new factors", tableOutput('cor_old_new')),
	  tabPanel("Scores", tableOutput('scores')), 
      tabPanel("Cor of Atr used in Reduction", verbatimTextOutput("intcors"))
    )
    
  )
))
