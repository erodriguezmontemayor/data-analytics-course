library(shiny)
library(knitr)

shinyServer(function(input, output,session) {
  callbootstrap<-reactive({
  source('style.R')
  
  })
  
  
	values <- reactiveValues()
  output$contents <- renderTable({
    
    # input$file1 will be NULL initially. After the user selects and uploads a 
    # file, it will be a data frame with 'name', 'size', 'type', and 'datapath' 
    # columns. The 'datapath' column will contain the local filenames where the 
    # data can be found.

    inFile <- input$file1

    if (is.null(inFile))
      return(NULL)
    
   values$thedata<-read.csv(inFile$datapath, header=input$header, sep=input$sep, quote=input$quote)
	
	values$thedata[1:10,]
	
  })
  output$intcors<-renderPrint({
  corthres = 0.4
values$thedata<-as.data.frame(values$thedata)
the_correlation = cor(values$thedata)
for (i in 1:(ncol(values$thedata) - 1)) {
    thecori = cor(values$thedata[, i], values$thedata)
    useonly = setdiff(which(abs(thecori) > corthres), i)
    labels_used = colnames(values$thedata)[useonly]
    thecori = matrix(thecori[useonly], nrow = 1)
    colnames(thecori) <- labels_used
    cat("\nAttribute", colnames(values$thedata)[i], "has these correlations above", 
        corthres, ": ")
    if (length(thecori) == 0) 
        cat("No Large Correlations") else sapply(1:ncol(thecori), function(j) cat(colnames(thecori)[j], ":", 
        thecori[j], ","))
}
  })
  
  
  output$summary<-renderTable({
  summary(values$thedata)
  })
  
  
  output$eigenvalues<-renderTable({
  library(FactoMineR)
  thedata<-values$thedata
  result <- PCA(thedata,graph=FALSE)
  eigenvalues<-result$eig
print(eigenvalues)
  })
  
  output$cor_old_new<-renderTable({
  library(FactoMineR)
  thedata<-values$thedata
  result <- PCA(thedata,graph=FALSE)
  corfactor <- result$var$cor
corfactornew<-as.data.frame(corfactor)
print(corfactornew)
  })
  
  output$scores<-renderTable({
  library(FactoMineR)
  thedata<-values$thedata
  result <- PCA(thedata,graph=FALSE)
  factormatrix <- result$ind$coord
facmat<-as.data.frame(factormatrix[1:10])
colnames(facmat)<-c("Score")
print(facmat)
  
  })
  
  
  output$plot<-renderPlot({
  library(FactoMineR)
  library(ggplot2)
  result <- PCA(values$thedata, graph=FALSE) # graphs generated automatically

# %interpretation of components
eigenvalues<-result$eig

# eigen values plot
x<-ggplot() +
  geom_line(aes(x = 1:length(eigenvalue),y = eigenvalue),data=eigenvalues,fun.data = mean_sdl,mult = 1,stat = 'summary') +
  xlab(label = 'Number of Factors') +
  ylab(label = 'Eigenvalues') +
  ggtitle(label = 'Scree Plot') +
  theme_classic() +
  theme_grey() +
  theme_bw() +
  theme_grey() +
  coord_cartesian(xlim = c(0 ,29),ylim = c(0,10)) +
  stat_abline(data=eigenvalues,intercept = 1.0,slope = 0.0,colour = '#00cc33',size = 1.0) +
  geom_point(aes(x = 1:length(eigenvalue),y = eigenvalue),data=eigenvalues,colour = '#3333ff')
print(x)
  
  })
  
  output$report = downloadHandler(
    filename = 'factor.html',
    
    content = function(file) {
      out = knit2html('factor.Rmd')
      file.rename(out, file) # move pdf to file for downloading
    },
    
    contentType = 'application/pdf'
  )
  
  
})
